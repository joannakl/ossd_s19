This is a repository designed to practice a workflow using 
fetch, merge, rebase, and a few other git commands.
